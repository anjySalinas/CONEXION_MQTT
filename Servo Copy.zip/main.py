#------------------------------ [IMPORT]------------------------------------
import network
from time import sleep 
import time
from machine import Pin,Timer
import dht
from umqtt.simple import MQTTClient
from machine import Pin, PWM, ADC, I2C
from neopixel import NeoPixel
#--------------------------- [OBJETOS]---------------------------------------
temporiza = Timer(0)
servo = PWM(Pin(14))
servo.freq(50)

pixels = NeoPixel(Pin(32), 16)

# Variables para servo
angulo = 0
step_size = 10
moving_forward = True

# MQTT Server Parameters
MQTT_CLIENT_ID = "Neo-Servo"
MQTT_BROKER    = "broker.hivemq.com"
MQTT_USER      = ""
MQTT_PASSWORD  = ""
topic_sub      = 'Proyecto/esp32'
#----------------------[ CONECTAR WIFI ]---------------------------------------------------------#
print("Conectando al WiFi", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect('Wokwi-GUEST', '')
while not sta_if.isconnected():
  print(".", end="")
  time.sleep(0.1)
print(" Connected!")
#----------------------[ FUNCION RECEPCION EN EL SUB ]---------------------------------------------------------#
def handle_message(topic, msg):
    global angulo, moving_forward

    if topic == b'Proyecto/esp32':
        msg_str = msg.decode().strip().lower()
        print(f"Mensaje recibido: {msg_str}")

        try:
            if msg_str.startswith("led:") or msg_str in ["rojo", "verde", "azul"]:
                if msg_str.startswith("led:"):
                    color = msg_str.split(":")[1]
                else:
                    color = msg_str

                if color == "rojo":
                    for i in range(16):
                        pixels[i] = (255, 0, 0)  # Rojo
                elif color == "verde":
                    for i in range(16):
                        pixels[i] = (0, 255, 0)  # Verde
                elif color == "azul":
                    for i in range(16):
                        pixels[i] = (0, 0, 255)  # Azul
                pixels.write()

            elif msg_str.startswith("servo:") or msg_str in ["0","90","180"]:
                    # Si el mensaje es tipo 'servo:<ángulo>'
                    if msg_str.startswith("servo:"):
                        angulo = int(msg_str.split(":")[1])

                    
                    elif msg_str == "0":
                        angulo = 0
                    elif msg_str == "90":
                        angulo = 90
                    elif msg_str == "180":
                        angulo = 179

                    # Verificar que el ángulo esté dentro del rango
                    if 0 <= angulo <= 180:
                        duty = int((angulo / 180) * 102 + 26)  # Mapeo a PWM duty
                        servo.duty(duty)
                        print(f"Servo a {angulo}° (duty={duty})")
                    else:
                        print("Ángulo fuera de rango")

        except ValueError:
            print("Error procesando el mensaje.")

#----------------------[ CONECTAR BROKER ]---------------------------------------------------------#
print("Connecting to MQTT server... ", end="")
client = MQTTClient(MQTT_CLIENT_ID, MQTT_BROKER, user=MQTT_USER, password=MQTT_PASSWORD)
client.set_callback(handle_message)
client.connect()
client.subscribe(topic_sub)
print("Connected!")
prev_weather = ""

#----------------------[ CICLO INFINITO ]---------------------------------------------------------#
while True:
  print ("esperando")
  client.wait_msg()